///////////////////////////////////////////////////////////////////////////////
// shadermanager.cpp
// ============
// manage the loading and rendering of 3D scenes
//
//  AUTHOR: Brian Battersby - SNHU Instructor / Computer Science
//	Created for CS-330-Computational Graphics and Visualization, Nov. 1st, 2023
///////////////////////////////////////////////////////////////////////////////

#include "SceneManager.h"

#ifndef STB_IMAGE_IMPLEMENTATION
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"
#endif

#include <glm/gtx/transform.hpp>

// declaration of global variables
namespace
{
	const char* g_ModelName = "model";
	const char* g_ColorValueName = "objectColor";
	const char* g_TextureValueName = "objectTexture";
	const char* g_UseTextureName = "bUseTexture";
	const char* g_UseLightingName = "bUseLighting";
}

/***********************************************************
 *  SceneManager()
 *
 *  The constructor for the class
 ***********************************************************/
SceneManager::SceneManager(ShaderManager *pShaderManager)
{
	m_pShaderManager = pShaderManager;
	m_basicMeshes = new ShapeMeshes();
}

/***********************************************************
 *  ~SceneManager()
 *
 *  The destructor for the class
 ***********************************************************/
SceneManager::~SceneManager()
{
	m_pShaderManager = NULL;
	delete m_basicMeshes;
	m_basicMeshes = NULL;
}

/***********************************************************
 *  CreateGLTexture()
 *
 *  This method is used for loading textures from image files,
 *  configuring the texture mapping parameters in OpenGL,
 *  generating the mipmaps, and loading the read texture into
 *  the next available texture slot in memory.
 ***********************************************************/
bool SceneManager::CreateGLTexture(const char* filename, std::string tag)
{
	int width = 0;
	int height = 0;
	int colorChannels = 0;
	GLuint textureID = 0;

	// indicate to always flip images vertically when loaded
	stbi_set_flip_vertically_on_load(true);

	// try to parse the image data from the specified image file
	unsigned char* image = stbi_load(
		filename,
		&width,
		&height,
		&colorChannels,
		0);

	// if the image was successfully read from the image file
	if (image)
	{
		std::cout << "Successfully loaded image:" << filename << ", width:" << width << ", height:" << height << ", channels:" << colorChannels << std::endl;

		glGenTextures(1, &textureID);
		glBindTexture(GL_TEXTURE_2D, textureID);

		// set the texture wrapping parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_MIRRORED_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
		// set texture filtering parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

		// if the loaded image is in RGB format
		if (colorChannels == 3)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB8, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image);
		// if the loaded image is in RGBA format - it supports transparency
		else if (colorChannels == 4)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, image);
		else
		{
			std::cout << "Not implemented to handle image with " << colorChannels << " channels" << std::endl;
			return false;
		}

		// generate the texture mipmaps for mapping textures to lower resolutions
		glGenerateMipmap(GL_TEXTURE_2D);

		// free the image data from local memory
		stbi_image_free(image);
		glBindTexture(GL_TEXTURE_2D, 0); // Unbind the texture

		// register the loaded texture and associate it with the special tag string
		m_textureIDs[m_loadedTextures].ID = textureID;
		m_textureIDs[m_loadedTextures].tag = tag;
		m_loadedTextures++;

		return true;
	}

	std::cout << "Could not load image:" << filename << std::endl;

	// Error loading the image
	return false;
}

/***********************************************************
 *  BindGLTextures()
 *
 *  This method is used for binding the loaded textures to
 *  OpenGL texture memory slots.  There are up to 16 slots.
 ***********************************************************/
void SceneManager::BindGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		// bind textures on corresponding texture units
		glActiveTexture(GL_TEXTURE0 + i);
		glBindTexture(GL_TEXTURE_2D, m_textureIDs[i].ID);
	}
}

/***********************************************************
 *  DestroyGLTextures()
 *
 *  This method is used for freeing the memory in all the
 *  used texture memory slots.
 ***********************************************************/
void SceneManager::DestroyGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		glGenTextures(1, &m_textureIDs[i].ID);
	}
}

/***********************************************************
 *  FindTextureID()
 *
 *  This method is used for getting an ID for the previously
 *  loaded texture bitmap associated with the passed in tag.
 ***********************************************************/
int SceneManager::FindTextureID(std::string tag)
{
	int textureID = -1;
	int index = 0;
	bool bFound = false;

	while ((index < m_loadedTextures) && (bFound == false))
	{
		if (m_textureIDs[index].tag.compare(tag) == 0)
		{
			textureID = m_textureIDs[index].ID;
			bFound = true;
		}
		else
			index++;
	}

	return(textureID);
}

/***********************************************************
 *  FindTextureSlot()
 *
 *  This method is used for getting a slot index for the previously
 *  loaded texture bitmap associated with the passed in tag.
 ***********************************************************/
int SceneManager::FindTextureSlot(std::string tag)
{
	int textureSlot = -1;
	int index = 0;
	bool bFound = false;

	while ((index < m_loadedTextures) && (bFound == false))
	{
		if (m_textureIDs[index].tag.compare(tag) == 0)
		{
			textureSlot = index;
			bFound = true;
		}
		else
			index++;
	}

	return(textureSlot);
}

/***********************************************************
 *  FindMaterial()
 *
 *  This method is used for getting a material from the previously
 *  defined materials list that is associated with the passed in tag.
 ***********************************************************/
bool SceneManager::FindMaterial(std::string tag, OBJECT_MATERIAL& material)
{
	if (m_objectMaterials.size() == 0)
	{
		return(false);
	}

	int index = 0;
	bool bFound = false;
	while ((index < m_objectMaterials.size()) && (bFound == false))
	{
		if (m_objectMaterials[index].tag.compare(tag) == 0)
		{
			bFound = true;
			material.ambientColor = m_objectMaterials[index].ambientColor;
			material.ambientStrength = m_objectMaterials[index].ambientStrength;
			material.diffuseColor = m_objectMaterials[index].diffuseColor;
			material.specularColor = m_objectMaterials[index].specularColor;
			material.shininess = m_objectMaterials[index].shininess;
		}
		else
		{
			index++;
		}
	}

	return(true);
}

/***********************************************************
 *  SetTransformations()
 *
 *  This method is used for setting the transform buffer
 *  using the passed in transformation values.
 ***********************************************************/
void SceneManager::SetTransformations(
	glm::vec3 scaleXYZ,
	float XrotationDegrees,
	float YrotationDegrees,
	float ZrotationDegrees,
	glm::vec3 positionXYZ)
{
	// variables for this method
	glm::mat4 modelView;
	glm::mat4 scale;
	glm::mat4 rotationX;
	glm::mat4 rotationY;
	glm::mat4 rotationZ;
	glm::mat4 translation;

	// set the scale value in the transform buffer
	scale = glm::scale(scaleXYZ);
	// set the rotation values in the transform buffer
	rotationX = glm::rotate(glm::radians(XrotationDegrees), glm::vec3(1.0f, 0.0f, 0.0f));
	rotationY = glm::rotate(glm::radians(YrotationDegrees), glm::vec3(0.0f, 1.0f, 0.0f));
	rotationZ = glm::rotate(glm::radians(ZrotationDegrees), glm::vec3(0.0f, 0.0f, 1.0f));
	// set the translation value in the transform buffer
	translation = glm::translate(positionXYZ);

	modelView = translation * rotationX * rotationY * rotationZ * scale;

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setMat4Value(g_ModelName, modelView);
	}
}

/***********************************************************
 *  SetShaderColor()
 *
 *  This method is used for setting the passed in color
 *  into the shader for the next draw command
 ***********************************************************/
void SceneManager::SetShaderColor(
	float redColorValue,
	float greenColorValue,
	float blueColorValue,
	float alphaValue)
{
	// variables for this method
	glm::vec4 currentColor;

	currentColor.r = redColorValue;
	currentColor.g = greenColorValue;
	currentColor.b = blueColorValue;
	currentColor.a = alphaValue;

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setIntValue(g_UseTextureName, false);
		m_pShaderManager->setVec4Value(g_ColorValueName, currentColor);
	}
}

/***********************************************************
 *  SetShaderTexture()
 *
 *  This method is used for setting the texture data
 *  associated with the passed in ID into the shader.
 ***********************************************************/
void SceneManager::SetShaderTexture(
	std::string textureTag)
{
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setIntValue(g_UseTextureName, true);

		int textureID = -1;
		textureID = FindTextureSlot(textureTag);
		m_pShaderManager->setSampler2DValue(g_TextureValueName, textureID);
	}
}

/***********************************************************
 *  SetTextureUVScale()
 *
 *  This method is used for setting the texture UV scale
 *  values into the shader.
 ***********************************************************/
void SceneManager::SetTextureUVScale(float u, float v)
{
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setVec2Value("UVscale", glm::vec2(u, v));
	}
}

/***********************************************************
 *  SetShaderMaterial()
 *
 *  This method is used for passing the material values
 *  into the shader.
 ***********************************************************/
void SceneManager::SetShaderMaterial(
	std::string materialTag)
{
	if (m_objectMaterials.size() > 0)
	{
		OBJECT_MATERIAL material;
		bool bReturn = false;

		bReturn = FindMaterial(materialTag, material);
		if (bReturn == true)
		{
			m_pShaderManager->setVec3Value("material.ambientColor", material.ambientColor);
			m_pShaderManager->setFloatValue("material.ambientStrength", material.ambientStrength);
			m_pShaderManager->setVec3Value("material.diffuseColor", material.diffuseColor);
			m_pShaderManager->setVec3Value("material.specularColor", material.specularColor);
			m_pShaderManager->setFloatValue("material.shininess", material.shininess);
		}
	}
}

/**************************************************************/
/*** STUDENTS CAN MODIFY the code in the methods BELOW for  ***/
/*** preparing and rendering their own 3D replicated scenes.***/
/*** Please refer to the code in the OpenGL sample project  ***/
/*** for assistance.                                        ***/
/**************************************************************/


/***********************************************************
 *  PrepareScene()
 *
 *  This method is used for preparing the 3D scene by loading
 *  the shapes, textures in memory to support the 3D scene 
 *  rendering
 ***********************************************************/
void SceneManager::PrepareScene()
{
	// load scene textures
	LoadSceneTextures();
	DefineObjectMaterials();
	SetupSceneLights();

	// load one instance of each mesh into memory
	m_basicMeshes->LoadPlaneMesh();
	m_basicMeshes->LoadCylinderMesh();
	m_basicMeshes->LoadTaperedCylinderMesh();
	m_basicMeshes->LoadSphereMesh();
	m_basicMeshes->LoadConeMesh();
	m_basicMeshes->LoadBoxMesh();
	m_basicMeshes->LoadTorusMesh();
}

/***********************************************************
 *  LoadSceneTextures()
 *
 *  This method is used for preparing the 3D scene by loading
 *  textures in memory to support the 3D scene
 ***********************************************************/
void SceneManager::LoadSceneTextures()
{
	bool bReturn = false;

	// Create textures
	bReturn = CreateGLTexture("../../Utilities/textures/knife_handle.jpg", "desk");
	bReturn = CreateGLTexture("../../Utilities/textures/black_metal.jpg", "legs");
	bReturn = CreateGLTexture("../../Utilities/textures/porcelain.jpg", "glass");
	bReturn = CreateGLTexture("../../Utilities/textures/stainless.jpg", "silver");
	bReturn = CreateGLTexture("../../Utilities/textures/breadcrust.jpg", "bread");
	bReturn = CreateGLTexture("../../Utilities/textures/abstract.jpg", "art");

	// after the texture image data is loaded into memory, the
	// loaded textures need to be bound to texture slots - there
	// are a total of 16 available slots for scene textures
	BindGLTextures();
}

/***********************************************************
*  DefineObjectMaterials()
*
*  This method is used for configuring the various material
*  settings for all of the objects in the 3D scene.
***********************************************************/
void SceneManager::DefineObjectMaterials() {

	OBJECT_MATERIAL plasticMaterial;
	plasticMaterial.ambientColor = glm::vec3(0.21f, 0.21f, 0.21f);
	plasticMaterial.ambientStrength = 0.5f;
	plasticMaterial.diffuseColor = glm::vec3(0.55f, 0.55f, 0.55f);
	plasticMaterial.specularColor = glm::vec3(0.3f, 0.3f, 0.3f);
	plasticMaterial.shininess = 6.0f;
	plasticMaterial.tag = "plastic";
	m_objectMaterials.push_back(plasticMaterial);

	OBJECT_MATERIAL silverMaterial;
	silverMaterial.ambientColor = glm::vec3(0.01f, 0.01f, 0.01f);
	silverMaterial.ambientStrength = 0.01f;
	silverMaterial.diffuseColor = glm::vec3(0.35f, 0.35f, 0.35f);
	silverMaterial.specularColor = glm::vec3(0.4f, 0.4f, 0.4f);
	silverMaterial.shininess = 8.0f;
	silverMaterial.tag = "silver";
	m_objectMaterials.push_back(silverMaterial);

	OBJECT_MATERIAL clothMaterial;
	clothMaterial.ambientColor = glm::vec3(0.1f, 0.1f, 0.1f);
	clothMaterial.ambientStrength = 0.1f;
	clothMaterial.diffuseColor = glm::vec3(0.5f, 0.5f, 0.2f);
	clothMaterial.specularColor = glm::vec3(0.05f, 0.05f, 0.05f);
	clothMaterial.shininess = 1.0f;
	clothMaterial.tag = "cloth";
	m_objectMaterials.push_back(clothMaterial);

	OBJECT_MATERIAL matteMaterial;
	matteMaterial.ambientColor = glm::vec3(0.1f, 0.1f, 0.1f);
	matteMaterial.ambientStrength = 0.1f;
	matteMaterial.diffuseColor = glm::vec3(0.3f, 0.3f, 0.1f);
	matteMaterial.specularColor = glm::vec3(0.1f, 0.1f, 0.1f);
	matteMaterial.shininess = 10.0f;
	matteMaterial.tag = "matte";
	m_objectMaterials.push_back(matteMaterial);

	OBJECT_MATERIAL metalMaterial;
	metalMaterial.ambientColor = glm::vec3(0.01f, 0.01f, 0.01f);
	metalMaterial.ambientStrength = 0.2f;
	metalMaterial.diffuseColor = glm::vec3(0.2f, 0.2f, 0.2f);
	metalMaterial.specularColor = glm::vec3(0.6f, 0.6f, 0.6f);
	metalMaterial.shininess = 16.0f;
	metalMaterial.tag = "metal";
	m_objectMaterials.push_back(metalMaterial);

	OBJECT_MATERIAL glassMaterial;
	glassMaterial.ambientColor = glm::vec3(0.21f, 0.21f, 0.21f);
	glassMaterial.ambientStrength = 0.8f;
	glassMaterial.diffuseColor = glm::vec3(0.1f, 0.1f, 0.1f);
	glassMaterial.specularColor = glm::vec3(0.5f, 0.5f, 0.5f);
	glassMaterial.shininess = 8.0f;
	glassMaterial.tag = "glass";
	m_objectMaterials.push_back(glassMaterial);
}

/***********************************************************
*  SetupSceneLights()
*
*  This method is used for configuring the scene lights.
***********************************************************/
void SceneManager::SetupSceneLights() {

	// Light 0: Sunlight - directional
	m_pShaderManager->setVec3Value("lightSources[0].position", 46.0f, 15.0f, -80.0f);
	m_pShaderManager->setVec3Value("lightSources[0].ambientColor", 0.05f, 0.05f, 0.1f);
	m_pShaderManager->setVec3Value("lightSources[0].diffuseColor", 0.6f, 0.6f, 0.7f);
	m_pShaderManager->setVec3Value("lightSources[0].specularColor", 0.4f, 0.4f, 0.4f);
	m_pShaderManager->setFloatValue("lightSources[0].focalStrength", 16.0f);
	m_pShaderManager->setFloatValue("lightSources[0].specularIntensity", 0.3f);

	// Light 1: Ceiling light - point
	m_pShaderManager->setVec3Value("lightSources[1].position", 10.0f, 50.0f, 0.0f);
	m_pShaderManager->setVec3Value("lightSources[1].ambientColor", 0.1f, 0.1f, 0.05f);
	m_pShaderManager->setVec3Value("lightSources[1].diffuseColor", 0.8f, 0.8f, 0.6f);
	m_pShaderManager->setVec3Value("lightSources[1].specularColor", 1.0f, 1.0f, 1.0f);
	m_pShaderManager->setFloatValue("lightSources[1].focalStrength", 32.0f);
	m_pShaderManager->setFloatValue("lightSources[1].specularIntensity", 1.0f);

	// Light 2: Reflected light from left wall
	m_pShaderManager->setVec3Value("lightSources[2].position", -30.0f, 0.0f, 10.0f);
	m_pShaderManager->setVec3Value("lightSources[2].ambientColor", 0.05f, 0.05f, 0.05f);
	m_pShaderManager->setVec3Value("lightSources[2].diffuseColor", 0.25f, 0.25f, 0.25f);
	m_pShaderManager->setVec3Value("lightSources[2].specularColor", 0.0f, 0.0f, 0.0f);
	m_pShaderManager->setFloatValue("lightSources[2].focalStrength", 1.0f);
	m_pShaderManager->setFloatValue("lightSources[2].specularIntensity", 0.0f);

	// Light 3: Reflected light from rear wall
	m_pShaderManager->setVec3Value("lightSources[3].position", 10.0f, 0.0f, 20.0f);
	m_pShaderManager->setVec3Value("lightSources[3].ambientColor", 0.05f, 0.05f, 0.05f);
	m_pShaderManager->setVec3Value("lightSources[3].diffuseColor", 0.15f, 0.15f, 0.15f);
	m_pShaderManager->setVec3Value("lightSources[3].specularColor", 0.0f, 0.0f, 0.0f);
	m_pShaderManager->setFloatValue("lightSources[3].focalStrength", 1.0f);
	m_pShaderManager->setFloatValue("lightSources[3].specularIntensity", 0.0f);

	// Use light sources rather than default lighting
	m_pShaderManager->setBoolValue("bUseLighting", true);
}

/***********************************************************
 *  DrawBirdModel()
 *
 *  This method is used for transforming and drawing
 *  the basic 3D shapes that make up the bird model
 *  given the center XYZ position of the base
 ***********************************************************/
void SceneManager::DrawBirdModel(float centerX, float centerY, float centerZ)
{
	// declare the variables for the transformations
	glm::vec3 scaleXYZ;
	float XrotationDegrees = 0.0f;
	float YrotationDegrees = 0.0f;
	float ZrotationDegrees = 0.0f;
	glm::vec3 positionXYZ;

	/******************************************************************/
	/*** Bird Legs - Cylinders                                      ***/
	/******************************************************************/

	// Set tiling for all bird parts
	SetTextureUVScale(2.0f, 2.0f);

	// Shader texture remains the same for all leg parts
	SetShaderTexture("legs");

	// Set material to metal
	SetShaderMaterial("metal");

	// Establish common vars for foot creation
	static float footLength = 1.1f;
	static float footWidth = 0.5f;

	// Draws right foot, then left foot
	for (int j = 0; j < 2; j++) {

		// Draw foot
		// set the XYZ scale for the mesh
		scaleXYZ = glm::vec3(0.025f, 1.1f, 0.025f);

		// set the XYZ rotation for the mesh
		XrotationDegrees = 90.0f;
		YrotationDegrees = 0.0f;
		ZrotationDegrees = 0.0f;

		// calculate XZ offset from center
		// add footwidth if second foot to prevent overlap
		float xOffset = centerX + (-0.5f * footWidth) + (j * footWidth);
		// subtract half of foot length so foot center
		// is at the center of the model
		float zOffset = centerZ + (-0.5f * footLength);

		// set the XYZ position for the mesh
		positionXYZ = glm::vec3(xOffset, centerY, zOffset);

		// set the transformations into memory to be used on the drawn meshes
		SetTransformations(
			scaleXYZ,
			XrotationDegrees,
			YrotationDegrees,
			ZrotationDegrees,
			positionXYZ);

		// draw the mesh with transformation values
		m_basicMeshes->DrawCylinderMesh();

		// Draw toes
		for (int i = 0; i < 2; i++) {
			// set the XYZ scale for the mesh
			scaleXYZ = glm::vec3(0.025f, 0.5f, 0.025f);

			// set the XYZ rotation for the mesh
			// separate toes by 30 degrees from foot center
			XrotationDegrees = 90.0f;
			YrotationDegrees = 0.0f;
			ZrotationDegrees = -30.0f + (i * 60.0f);

			// set the XYZ position for the mesh
			// get foot and add offset to center
			positionXYZ = glm::vec3(xOffset, centerY, centerZ);

			// set the transformations into memory to be used on the drawn meshes
			SetTransformations(
				scaleXYZ,
				XrotationDegrees,
				YrotationDegrees,
				ZrotationDegrees,
				positionXYZ);

			// draw the mesh with transformation values
			m_basicMeshes->DrawCylinderMesh();
		}

		// Draw lower leg
		// set the XYZ scale for the mesh
		scaleXYZ = glm::vec3(0.025f, 0.75f, 0.025f);

		// set the XYZ rotation for the mesh
		XrotationDegrees = 0.0f;
		YrotationDegrees = 0.0f;
		ZrotationDegrees = 0.0f;

		// set the XYZ position for the mesh based on foot position
		positionXYZ = glm::vec3(xOffset, centerY, centerZ);

		// set the transformations into memory to be used on the drawn meshes
		SetTransformations(
			scaleXYZ,
			XrotationDegrees,
			YrotationDegrees,
			ZrotationDegrees,
			positionXYZ);

		// draw the mesh with transformation values
		m_basicMeshes->DrawCylinderMesh();

		// Draw upper leg
		// set the XYZ scale for the mesh
		scaleXYZ = glm::vec3(0.025f, 0.5f, 0.025f);

		// set the XYZ rotation for the mesh
		XrotationDegrees = 30.0f;
		YrotationDegrees = 0.0f;
		ZrotationDegrees = 0.0f;

		// set the XYZ position for the mesh based on foot position
		positionXYZ = glm::vec3(xOffset, (centerY + 0.75f), centerZ);

		// set the transformations into memory to be used on the drawn meshes
		SetTransformations(
			scaleXYZ,
			XrotationDegrees,
			YrotationDegrees,
			ZrotationDegrees,
			positionXYZ);

		// draw the mesh with transformation values
		m_basicMeshes->DrawCylinderMesh();
	}

	/******************************************************************/
	/*** Body - Cylinder and Sphere                                 ***/
	/******************************************************************/

	// Set shader texture for body
	SetShaderTexture("glass");

	// Set material to matte
	SetShaderMaterial("glass");

	// Draw lower body
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(0.65f, 0.4f, 0.65f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 180.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// establish lastY variable for increasing height of meshes
	float lastY = (centerY + 0.75f);
	// increase by approximate height of last mesh
	lastY = lastY + 0.7f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(centerX, lastY, (centerZ + 0.2f));

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// draw the mesh with transformation values
	m_basicMeshes->DrawTaperedCylinderMesh();

	// Draw upper body
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(0.75f, 0.60f, 0.75f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// increase by lastY by specified height
	lastY = lastY + 0.29f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(centerX, lastY, (centerZ + 0.2f));

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// draw the mesh with transformation values
	m_basicMeshes->DrawSphereMesh();

	// Draw tail section
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(0.6f, 1.0f, 0.6f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = -45.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(centerX, lastY + 0.1f, centerZ);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// draw the mesh with transformation values
	m_basicMeshes->DrawConeMesh();

	/******************************************************************/
	/*** Head - Sphere and Cone                                     ***/
	/******************************************************************/

	// Draw head
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(0.25f, 0.25f, 0.25f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	lastY = lastY - 0.1f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(centerX, lastY, centerZ + 1.0f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// draw the mesh with transformation values
	m_basicMeshes->DrawSphereMesh();

	// Draw beak
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(0.05f, 0.1f, 0.05f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 90.0f;
	YrotationDegrees = -30.0f;
	ZrotationDegrees = -45.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(centerX + 0.1f, lastY - 0.1f, centerZ + 1.15f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// draw the mesh with transformation values
	m_basicMeshes->DrawConeMesh();
}

/***********************************************************
 *  RenderScene()
 *
 *  This method is used for rendering the 3D scene by 
 *  transforming and drawing the basic 3D shapes
 ***********************************************************/
void SceneManager::RenderScene()
{
	// declare the variables for the transformations
	glm::vec3 scaleXYZ;
	float XrotationDegrees = 0.0f;
	float YrotationDegrees = 0.0f;
	float ZrotationDegrees = 0.0f;
	glm::vec3 positionXYZ;

	/******************************************************************/
	/*** Desk - Plane Mesh                                          ***/
	/******************************************************************/
	
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(5.5f, 1.0f, 12.0f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 60.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(0.0f, 0.0f, 0.0f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// Set tiling
	SetTextureUVScale(4.0f, 4.0f);

	// Set to dark wood texture
	SetShaderTexture("desk");

	// Set material to matte
	SetShaderMaterial("matte");

	// draw the mesh with transformation values
	m_basicMeshes->DrawPlaneMesh();

	/******************************************************************/
	/*** Board Game - Box Mesh                                      ***/
	/******************************************************************/
	
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(6.0f, 3.0f, 6.0f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = -30.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(-5.0f, 1.6f, -5.0f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// Set tiling
	SetTextureUVScale(1.0f, 1.0f);

	// Set Shader texture to abstract
	SetShaderTexture("art");

	// Set material to matte
	SetShaderMaterial("cloth");

	// draw the mesh with transformation values
	m_basicMeshes->DrawBoxMesh();

	/******************************************************************/
	/*** Lamp - Cylinder Mesh                                       ***/
	/******************************************************************/
	
	// Draw lamp base
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(1.0f, 1.5f, 1.0f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(5.0f, 0.1f, 2.0f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// Set tiling
	SetTextureUVScale(1.0f, 1.0f);

	// Set texture to silver
	SetShaderTexture("silver");

	// Set material to plastic
	SetShaderMaterial("silver");

	// draw the mesh with transformation values
	m_basicMeshes->DrawCylinderMesh();

	// Draw upper lamp light
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(1.0f, 3.5f, 1.0f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(5.0f, 1.6f, 2.0f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// Set color to white
	SetShaderColor(1,1,1,1);

	// Set material to white plastic
	SetShaderMaterial("plastic");

	// draw the mesh with transformation values
	m_basicMeshes->DrawCylinderMesh();

	/******************************************************************/
	/*** Donut Pillow - Torus Mesh                                  ***/
	/******************************************************************/

	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(6.0f, 6.0f, 6.0f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = -45.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 45.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(-4.5f, 2.9f, 0.0f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// Set tiling
	SetTextureUVScale(4.0f, 4.0f);

	// Set texture to bread
	SetShaderTexture("bread");

	// Set material to matte
	SetShaderMaterial("cloth");

	// draw the mesh with transformation values
	m_basicMeshes->DrawTorusMesh();

	/******************************************************************/
	/*** Bird - Complex Mesh                                        ***/
	/******************************************************************/

	// Draws complex bird model given the center of its base
	DrawBirdModel(2.5f, 0.1f, 1.0f);

}